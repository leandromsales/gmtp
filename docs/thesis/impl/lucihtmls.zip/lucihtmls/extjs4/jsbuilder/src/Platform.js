Platform = {
    isUnix: Fs.sep == '/',
    isWindows: Fs.sep != '/'
};